package kr.or.kosta.dto;

public class ExcelTestVO {

}
