package kr.or.kosta.dto;

public class Movie_tagVO {
	String movie_number, Tag_Table_num;
	
	

	public String getMovie_number() {
		return movie_number;
	}

	public void setMovie_number(String movie_number) {
		this.movie_number = movie_number;
	}

	public String getTag_Table_num() {
		return Tag_Table_num;
	}
	
	

	public void setTag_Table_num(String tag_Table_num) {
		Tag_Table_num = tag_Table_num;
	}
	
	

}
